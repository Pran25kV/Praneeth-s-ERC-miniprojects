clear;
clc;
close all;
T = 0:0.01:5;
amplitude = 10;
frequency = 0.5;
theta = amplitude*sin(2*pi*frequency*T); %s of sin in lower case, uppercase T, problem gets fixed (case sensitivity)
plot(T,theta,'LineWidth',2)  %"time" is an undeclared variable
xlabel('Time (s)'); ylabel('Angle(deg)')
title('Pendulum Angle')
grid of

% The corrected code displays a sine wave graph depicting the instantaneous
% angle of a pendulum as it oscillates