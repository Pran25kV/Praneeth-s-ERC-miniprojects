clear;
clc;
close all;
amplitude = input("Enter amplitude")
frequency = input("Enter frequency")
if (frequency<=0)
    disp("Try again! Please enter a non-negative value of frequency")
    return
end

T = 0:0.01:5;
theta = (amplitude*pi/180)*sin(2*pi*frequency*T);
linecolour = [0 0 0];

if (max(abs(theta)))<(5*pi/180)
    disp("Stable")
    lineColour = [0 1 0];
elseif (max(abs(theta)))<=(10*pi/180)
    disp("Needs Attention")
    lineColour = [1 0.5 0];
else
    disp("Large Angle")
    lineColour = [1 0 0];
end

plot(T,theta,'Color',lineColour,'LineWidth',2)
