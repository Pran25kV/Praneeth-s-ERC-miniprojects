clear;
clc;
close all;
amplitude = input("Enter amplitude")
frequency = input("Enter frequency")
if (frequency<=0)
    disp("Try again! Please enter a non-negative value of frequency")
    return
end

T = 0:0.01:5;
theta = amplitude*sin(2*pi*frequency*T);
plot(T,theta,'LineWidth',2)
disp(max(abs(theta)))
