clear;
clc;

% Values you can change:

theta0_deg = 5;          % initial angle: use 3, 5 and 8 degrees for testing Q2
open_loop_force_N = 0;   % keep zero for open-loop tests

theta_target_deg = 0;    % desired upright angle

K = 0;
Fmax = 10;               % maximum controller force in N (magnitude)

Kp = 20;                    
Ki = 10;                  % changed this to 10 from 2 for demoing Q4
Kd = 2;  
N = 100; 
sim_stop_time = 6;
push_N = 0.5;            % first try 0, then 0.5
push_start_s = 2; 
push_end_s = 2.2;

% PENDULUM PARAMETERS - DO NOT CHANGE

M = 0.5;
m = 0.2; 
b = 0.1;
I = 0.006;
l = 0.3;
g = 9.81;

theta0_rad = deg2rad(theta0_deg);
theta_target_rad = deg2rad(theta_target_deg);

x0 = 0;
x_dot0 = 0;
theta_dot0 = 0;
x_init = [x0;x_dot0;theta0_rad;theta_dot0];

p = I*(M + m) + M*m*l^2;

A = [0, 1, 0, 0;
     0, -(I + m*l^2)*b/p, (m^2*g*l^2)/p, 0;
     0, 0, 0, 1;
     0, -(m*l*b)/p, m*g*l*(M + m)/p, 0];

B = [0;
     (I + m*l^2)/p;
     0;
     m*l/p];

C = eye(4);

D = zeros(4,1);

disp('Pendulum parameters loaded successfully.');
disp(['Initial angle: ', num2str(theta0_deg), ' degrees']);
disp(['Controller gain K: ', num2str(K)]);
disp(['Force limit: +/-', num2str(Fmax), ' N']);